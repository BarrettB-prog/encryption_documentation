.. Encryption_documentation documentation master file, created by
   sphinx-quickstart on Thu Jul 11 13:12:56 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Encryption_documentation's documentation!
====================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   secret_util


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
